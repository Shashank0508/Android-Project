package com.example.additem.model

data class UserData (
    var userName:String,
    var userMb:String,
    var userdata:String
)